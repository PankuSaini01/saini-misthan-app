import React from "react";

const items = [
  { name: "Rasgulla", price: 180 },
  { name: "Gulab Jamun", price: 200 },
  { name: "Khoa Burfi", price: 500 },
  { name: "Khoa Peda", price: 500 },
  { name: "Milk Cake (Kalakand)", price: 500 },
  { name: "Besan Laddu", price: 200 },
  { name: "Boondi Laddu", price: 180 },
  { name: "Patisa (Normal)", price: 160 },
  { name: "Patisa (Desi Ghee)", price: 360 },
  { name: "Doda Burfi", price: 350 },
  { name: "Petha", price: 120 },
  { name: "Samosa", price: 20 },
  { name: "Chole Samosa", price: 30 },
  { name: "Imarti (Festival)", price: 350 },
  { name: "Kaju Katli (Festival)", price: 800 },
  { name: "Dudh ka Ghewar (Monsoon)", price: 260 },
  { name: "Khoa ka Ghewar (Monsoon)", price: 480 }
];

function App() {
  return (
    <div style={{ maxWidth: 600, margin: "0 auto", padding: 16 }}>
      <h1 style={{ textAlign: "center" }}>Saini Misthan Bhandar</h1>
      <p style={{ textAlign: "center", color: "#888" }}>
        Since 1984 – Known for Delicious Taste & Antique Samosa
      </p>
      <input
        type="text"
        placeholder="Search for sweets or snacks..."
        style={{
          width: "100%",
          padding: 10,
          margin: "20px 0",
          borderRadius: 8,
          border: "1px solid #ccc"
        }}
      />
      <ul style={{ listStyle: "none", padding: 0 }}>
        {items.map((item, idx) => (
          <li
            key={idx}
            style={{
              display: "flex",
              justifyContent: "space-between",
              padding: 10,
              borderBottom: "1px solid #eee"
            }}
          >
            <span>{item.name}</span>
            <span>₹{item.price}/kg</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;